function [ B ] = DisplayMosaic( A,m,n )
%DISPLAYMOSAIC displays a m-by-n mosaic of the color picture A



end

